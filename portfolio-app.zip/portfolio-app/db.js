// db.js
// A tiny, dependency-free JSON-file "database".
//
// Why a JSON file instead of a real database engine?
// This keeps the project runnable with zero `npm install` steps, which is
// ideal for a personal portfolio. Node is single-threaded and every write
// here is synchronous, so there's no race-condition risk at the traffic
// level a personal site sees. If you outgrow this (thousands of visitors,
// multiple server instances, etc.), swap this module for a real database
// (Postgres/SQLite/etc.) — every other file only talks to the functions
// exported here, so that's the only file you'd need to change.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "data", "db.json");

const DEFAULT_PORTFOLIO = {
  name: "Jordan Ellis",
  role: "Independent Creative — Brand, Web & Visual Direction",
  tagline: "I help small studios and founders look like they mean it.",
  intro: "Ten years freelancing across brand identity, web design, and art direction. This is sample content — edit everything from the admin dashboard.",
  email: "hello@example.com",
  location: "Based anywhere, working everywhere",
  issue: "No. 01",
  skills: [
    { id: "s1", name: "Brand Identity", detail: "Logo systems and guidelines that survive contact with a marketing team." },
    { id: "s2", name: "Web Design", detail: "Marketing sites and product UI, built to load fast and read well." },
    { id: "s3", name: "Art Direction", detail: "Shoots, campaigns, and the moodboards that hold them together." },
    { id: "s4", name: "Copywriting", detail: "Voice and messaging that sounds like a person wrote it." }
  ],
  projects: [
    { id: "p1", title: "Nocturne Records", category: "Brand Identity", year: "2025", description: "A visual identity for an independent label.", tags: ["Branding", "Type"], imageUrl: "" },
    { id: "p2", title: "Hearth & Coal", category: "Web Design", year: "2024", description: "A restaurant site built to sell the tasting menu.", tags: ["Web", "UI"], imageUrl: "" }
  ],
  testimonials: [
    { id: "t1", quote: "Handed over a vague idea and got back a brand that finally felt like us.", name: "Mara Cole", role: "Founder, Nocturne Records" }
  ]
};

function emptyDb() {
  return {
    portfolio: DEFAULT_PORTFOLIO,
    adminAuth: null, // { salt, hash } — set on first run
    sessions: {},    // token -> { expiresAt }
    conversations: {}, // visitorId -> { meta, messages: [], unreadAdmin, unreadVisitor }
    analytics: { visits: { total: 0, byDay: {} }, clicks: {} }
  };
}

function ensureDbFile() {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(emptyDb(), null, 2));
  }
}

function readDb() {
  ensureDbFile();
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, "utf8"));
  } catch (e) {
    console.error("[db] Failed to parse db.json, starting from a fresh database:", e.message);
    const fresh = emptyDb();
    writeDb(fresh);
    return fresh;
  }
}

function writeDb(data) {
  ensureDbFile();
  // write to a temp file then rename — avoids a half-written file if the
  // process is killed mid-write.
  const tmp = DB_PATH + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, DB_PATH);
}

/** Run `mutator(db)` and persist the result. Returns whatever mutator returns. */
function update(mutator) {
  const data = readDb();
  const result = mutator(data);
  writeDb(data);
  return result;
}

module.exports = { readDb, writeDb, update, DEFAULT_PORTFOLIO };
