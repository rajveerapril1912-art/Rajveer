// sse.js
// Minimal Server-Sent Events hub. This is what gives the admin inbox and
// the visitor chat *real* real-time updates (no polling), using only
// plain HTTP — no extra dependencies, no WebSocket library needed.

const adminClients = new Set();
const visitorClients = new Map(); // visitorId -> Set(res)

function sseHeaders(res) {
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no"
  });
  res.write(": connected\n\n");
}

function addAdminClient(res) {
  sseHeaders(res);
  adminClients.add(res);
  const keepAlive = setInterval(() => res.write(": ping\n\n"), 25000);
  res.on("close", () => { clearInterval(keepAlive); adminClients.delete(res); });
}

function addVisitorClient(visitorId, res) {
  sseHeaders(res);
  if (!visitorClients.has(visitorId)) visitorClients.set(visitorId, new Set());
  visitorClients.get(visitorId).add(res);
  const keepAlive = setInterval(() => res.write(": ping\n\n"), 25000);
  res.on("close", () => {
    clearInterval(keepAlive);
    const set = visitorClients.get(visitorId);
    if (set) { set.delete(res); if (set.size === 0) visitorClients.delete(visitorId); }
  });
}

function send(res, event, data) {
  res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
}

function notifyAdmins(event, data) {
  for (const res of adminClients) send(res, event, data);
}

function notifyVisitor(visitorId, event, data) {
  const set = visitorClients.get(visitorId);
  if (!set) return;
  for (const res of set) send(res, event, data);
}

module.exports = { addAdminClient, addVisitorClient, notifyAdmins, notifyVisitor };
