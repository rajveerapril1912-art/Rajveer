# Portfolio — real backend edition

A self-hosted portfolio site with:

- An **AI assistant** ("Ask the Studio") that answers visitor questions using your real skills/projects as context
- A **visitor inquiry chatbox** ("Leave a Note") gated by email + phone, saved to a real database, with live real-time replies
- A password-protected **admin dashboard** ("Studio Desk") — inbox with instant push updates, a portfolio content editor, analytics, and settings
- **Real, working authentication** (hashed passwords, secure sessions, login rate-limiting) and a **real database** (a JSON file to start — see "Growing up" below)

No frontend framework, no build step, and **zero npm dependencies** — it runs with nothing but Node.js itself.

## 1. Requirements

- [Node.js](https://nodejs.org) version 18 or later (for its built-in `fetch`). Check with `node --version`.
- Optionally, an [Anthropic API key](https://console.anthropic.com) if you want the AI assistant to actually respond (Settings → API Keys in the Console).

## 2. Run it locally

```bash
cd portfolio-app
cp .env.example .env      # then open .env and fill in what you want
node server.js
```

Open **http://localhost:3000** for the portfolio, and **http://localhost:3000/admin** for the dashboard.

The very first time you start the server, if you didn't set `ADMIN_INITIAL_PASSWORD` in `.env`, a random password is generated and printed **once to your terminal** (not shown anywhere in the browser). Copy it, log in, and change it immediately from **Settings**.

## 3. Configure the AI assistant

Open `.env` and set:

```
ANTHROPIC_API_KEY=sk-ant-...
```

Get a key from the [Claude Console](https://console.anthropic.com) → Settings → API Keys. Until this is set, "Ask the Studio" will show a polite "not configured yet" message instead of breaking anything else on the site. The key never reaches the browser — the server calls Anthropic on the visitor's behalf, which is the secure way to do this (client-side API keys can be read by anyone who opens dev tools).

## 4. Put your real content in

Log into `/admin` and use the **Portfolio** tab to replace the sample name, bio, skills, projects (with your own image URLs), and testimonials. Everything saves to the database immediately.

## 5. Deploy it somewhere real

This is a plain Node.js HTTP server, so it runs on almost any host that supports Node:

- **Render / Railway / Fly.io** — connect your git repo, set the start command to `node server.js`, add your environment variables (`ANTHROPIC_API_KEY`, `ADMIN_INITIAL_PASSWORD`) in their dashboard, and deploy.
- **A VPS (DigitalOcean, Hetzner, etc.)** — copy the folder up, run `node server.js` behind a process manager like `pm2`, and put Nginx or Caddy in front of it for HTTPS.

A few things to double check when you deploy:

- Make sure the platform gives you **persistent disk storage** for the `data/` folder — some serverless/edge platforms wipe the filesystem between requests, which would erase your messages and portfolio edits. Render, Railway, Fly.io, and a plain VPS are all fine for this. If your host doesn't offer persistent disk, see "Growing up" below.
- Serve over **HTTPS** (most of the platforms above do this for you automatically) — the session cookie is marked `Secure` when it detects HTTPS, which browsers require in order to actually send it back.

## 6. How the security works

- **Passwords** are hashed with `scrypt` (Node's built-in, no bcrypt needed) — never stored or logged in plain text.
- **Sessions** are random 256-bit tokens stored server-side, delivered via an `HttpOnly`, `SameSite=Strict` cookie — JavaScript on the page can't read it, and it won't be sent along with cross-site requests.
- **Login attempts** are rate-limited per IP (8 attempts per 15 minutes) to slow down brute-forcing.
- **The AI assistant's API key** lives only in your server's `.env` file and is never sent to the browser.
- **Visitor input** is always rendered as plain text (never `innerHTML`), so a visitor can't inject a script into your admin inbox.

This is a genuinely reasonable security setup for a personal site. It is not an audited enterprise system — if this ever handles anything more sensitive than portfolio inquiries, get a real security review first.

## 7. Growing up: swapping the database later

Right now, everything lives in `data/db.json`, read and written by `db.js`. That's intentional — it means you can run this whole project with **zero installs**. It comfortably handles the traffic a personal portfolio gets.

If you outgrow it (heavy traffic, multiple server instances, etc.), every other file only ever calls the functions exported from `db.js` (`readDb`, `writeDb`, `update`) — so migrating to Postgres/SQLite/MongoDB later means rewriting that one file, not the rest of the app.

## 8. Project structure

```
portfolio-app/
  server.js        — HTTP server + all API routes
  db.js            — JSON-file database
  auth.js          — password hashing, sessions, rate limiting
  sse.js           — real-time push (Server-Sent Events)
  .env.example     — copy to .env and fill in
  data/db.json     — created automatically on first run
  public/
    index.html     — portfolio page
    admin.html     — admin dashboard page
    css/styles.css
    js/
      icons.js     — inline SVG icon set
      utils.js     — shared DOM/fetch helpers
      site.js      — renders the portfolio + both chat widgets
      admin.js     — the admin dashboard
```

## 9. What's genuinely real-time here

The admin inbox and the visitor chat both use **Server-Sent Events** (`/api/admin/stream`, `/api/visitor/:id/stream`) — a live, standing HTTP connection the server pushes updates through instantly. That's real push, not polling. Browser notifications (via the Notification API) also fire when a new message arrives while the tab is open or in the background — enable them from the visitor prompt or from **Settings** in the admin dashboard.

The one thing this doesn't cover is notifications when the site is **completely closed** (no tab open at all) — that requires a service worker + the Push API + a signed VAPID key pair, which is a reasonable next step if you want it, but is a step up in complexity from everything else here.
