// auth.js
// Password hashing, session tokens, and login rate limiting.
// Uses only Node's built-in `crypto` module — no bcrypt/jsonwebtoken needed.

const crypto = require("crypto");
const db = require("./db");

const SESSION_COOKIE = "session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return { salt, hash };
}

function verifyPassword(password, salt, hash) {
  const candidate = crypto.scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (candidate.length !== expected.length) return false;
  return crypto.timingSafeEqual(candidate, expected);
}

function ensureAdminAccount() {
  return db.update((data) => {
    if (!data.adminAuth) {
      const initialPassword = process.env.ADMIN_INITIAL_PASSWORD || crypto.randomBytes(6).toString("hex");
      data.adminAuth = hashPassword(initialPassword);
      // Only ever printed to the server's own console/log — never sent to a browser.
      console.log("\n============================================================");
      console.log(" First run: no admin password was set.");
      console.log(" Generated admin password: " + initialPassword);
      console.log(" Log in, then change it immediately from Settings.");
      console.log(" (Set ADMIN_INITIAL_PASSWORD in your .env to control this next time.)");
      console.log("============================================================\n");
    }
    return data.adminAuth;
  });
}

function createSession() {
  const token = crypto.randomBytes(32).toString("hex");
  db.update((data) => {
    data.sessions[token] = { expiresAt: Date.now() + SESSION_TTL_MS };
    // Opportunistically clean up expired sessions.
    for (const t of Object.keys(data.sessions)) {
      if (data.sessions[t].expiresAt < Date.now()) delete data.sessions[t];
    }
  });
  return token;
}

function destroySession(token) {
  db.update((data) => { delete data.sessions[token]; });
}

function isSessionValid(token) {
  if (!token) return false;
  const data = db.readDb();
  const session = data.sessions[token];
  return !!session && session.expiresAt > Date.now();
}

// --- very small in-memory login rate limiter (per IP) ---
const attempts = new Map(); // ip -> [timestamps]
const WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 8;

function isRateLimited(ip) {
  const now = Date.now();
  const list = (attempts.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  attempts.set(ip, list);
  return list.length >= MAX_ATTEMPTS;
}

function recordAttempt(ip) {
  const list = attempts.get(ip) || [];
  list.push(Date.now());
  attempts.set(ip, list);
}

function clearAttempts(ip) {
  attempts.delete(ip);
}

function parseCookies(req) {
  const header = req.headers.cookie || "";
  const out = {};
  header.split(";").forEach((pair) => {
    const idx = pair.indexOf("=");
    if (idx === -1) return;
    const k = pair.slice(0, idx).trim();
    const v = pair.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  });
  return out;
}

function isHttps(req) {
  return req.socket.encrypted || req.headers["x-forwarded-proto"] === "https";
}

function setSessionCookie(req, res, token) {
  const parts = [
    `${SESSION_COOKIE}=${encodeURIComponent(token)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Strict",
    `Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`
  ];
  if (isHttps(req)) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

function clearSessionCookie(req, res) {
  const parts = [`${SESSION_COOKIE}=`, "Path=/", "HttpOnly", "SameSite=Strict", "Max-Age=0"];
  if (isHttps(req)) parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

function getSessionToken(req) {
  return parseCookies(req)[SESSION_COOKIE];
}

function requireAuth(req) {
  return isSessionValid(getSessionToken(req));
}

module.exports = {
  hashPassword, verifyPassword, ensureAdminAccount,
  createSession, destroySession, isSessionValid,
  isRateLimited, recordAttempt, clearAttempts,
  parseCookies, setSessionCookie, clearSessionCookie, getSessionToken, requireAuth
};
