// server.js
// A real, self-contained backend for the portfolio — zero npm dependencies.
// Run with: node server.js  (Node 18+ required for built-in fetch)

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const db = require("./db");
const auth = require("./auth");
const sse = require("./sse");

// Load .env manually (no dotenv dependency) — simple KEY=VALUE per line.
(function loadEnv() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, "utf8").split("\n")) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    let val = trimmed.slice(idx + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = val;
  }
})();

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, "public");
const MAX_BODY_BYTES = 200 * 1024; // 200kb — plenty for this app, guards against abuse

auth.ensureAdminAccount();

/* ---------------------------------------------------------------
   SMALL HELPERS
----------------------------------------------------------------*/
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(body) });
  res.end(body);
}

function sanitizeKey(str) {
  return String(str).trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120) || "guest";
}

function dayKey(ts = Date.now()) {
  return new Date(ts).toISOString().slice(0, 10);
}

function isValidEmail(v) {
  return typeof v === "string" && /^\S+@\S+\.\S+$/.test(v);
}

function clientIp(req) {
  const fwd = req.headers["x-forwarded-for"];
  if (fwd) return fwd.split(",")[0].trim();
  return req.socket.remoteAddress || "unknown";
}

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(Object.assign(new Error("Payload too large"), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      if (chunks.length === 0) return resolve({});
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));
      } catch (e) {
        reject(Object.assign(new Error("Invalid JSON"), { statusCode: 400 }));
      }
    });
    req.on("error", reject);
  });
}

// Strip any private/internal fields before a portfolio object leaves the server.
function publicPortfolio(p) {
  const { name, role, tagline, intro, email, location, issue, skills, projects, testimonials } = p;
  return { name, role, tagline, intro, email, location, issue, skills, projects, testimonials };
}

function conversationSummary(conv, key) {
  return {
    id: key,
    meta: conv.meta,
    unreadAdmin: conv.unreadAdmin || 0,
    lastMessage: conv.messages[conv.messages.length - 1] || null,
    messageCount: conv.messages.length
  };
}

/* ---------------------------------------------------------------
   STATIC FILE SERVING
----------------------------------------------------------------*/
const MIME = {
  ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".svg": "image/svg+xml",
  ".ico": "image/x-icon", ".woff2": "font/woff2"
};

function serveStatic(req, res, pathname) {
  let rel = pathname === "/" ? "/index.html" : pathname;
  if (rel === "/admin") rel = "/admin.html";
  const filePath = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!filePath.startsWith(PUBLIC_DIR)) { sendJson(res, 403, { error: "Forbidden" }); return; }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      // SPA-ish fallback: unknown non-file routes just get index.html
      if (!path.extname(filePath)) {
        fs.readFile(path.join(PUBLIC_DIR, "index.html"), (e2, d2) => {
          if (e2) { sendJson(res, 404, { error: "Not found" }); return; }
          res.writeHead(200, { "Content-Type": MIME[".html"] });
          res.end(d2);
        });
        return;
      }
      sendJson(res, 404, { error: "Not found" });
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
    res.end(data);
  });
}

/* ---------------------------------------------------------------
   ROUTE HANDLERS
----------------------------------------------------------------*/

async function handlePublicPortfolio(req, res) {
  const data = db.readDb();
  sendJson(res, 200, publicPortfolio(data.portfolio));
}

async function handleTrackVisit(req, res) {
  db.update((data) => {
    data.analytics.visits.total = (data.analytics.visits.total || 0) + 1;
    const k = dayKey();
    data.analytics.visits.byDay[k] = (data.analytics.visits.byDay[k] || 0) + 1;
  });
  sendJson(res, 200, { ok: true });
}

async function handleTrackClick(req, res) {
  const body = await readJsonBody(req);
  const projectId = String(body.projectId || "").slice(0, 64);
  if (!projectId) return sendJson(res, 400, { error: "projectId required" });
  db.update((data) => {
    data.analytics.clicks[projectId] = (data.analytics.clicks[projectId] || 0) + 1;
  });
  sendJson(res, 200, { ok: true });
}

async function handleVisitorStart(req, res) {
  const body = await readJsonBody(req);
  const name = String(body.name || "Visitor").slice(0, 120);
  const email = String(body.email || "").slice(0, 200);
  const phone = String(body.phone || "").slice(0, 60);
  if (!isValidEmail(email)) return sendJson(res, 400, { error: "A valid email is required." });
  if (!phone.trim()) return sendJson(res, 400, { error: "A phone number is required." });

  const visitorId = "conv-" + sanitizeKey(email);
  const conv = db.update((data) => {
    if (!data.conversations[visitorId]) {
      data.conversations[visitorId] = {
        meta: { name, email, phone, createdAt: Date.now() },
        messages: [{ id: crypto.randomUUID(), sender: "admin", text: "Thanks for reaching out — tell me a bit about your project and I'll get back to you personally.", ts: Date.now() }],
        unreadAdmin: 0,
        unreadVisitor: 0
      };
    } else {
      data.conversations[visitorId].meta.name = name || data.conversations[visitorId].meta.name;
      data.conversations[visitorId].meta.phone = phone;
      data.conversations[visitorId].unreadVisitor = 0;
    }
    return data.conversations[visitorId];
  });
  sendJson(res, 200, { visitorId, messages: conv.messages });
}

async function handleVisitorMessages(req, res, visitorId) {
  const data = db.readDb();
  const conv = data.conversations[visitorId];
  if (!conv) return sendJson(res, 404, { error: "Conversation not found" });
  sendJson(res, 200, { messages: conv.messages });
}

async function handleVisitorSend(req, res, visitorId) {
  const body = await readJsonBody(req);
  const text = String(body.text || "").trim().slice(0, 4000);
  if (!text) return sendJson(res, 400, { error: "Message text required" });
  const conv = db.update((data) => {
    const c = data.conversations[visitorId];
    if (!c) return null;
    const msg = { id: crypto.randomUUID(), sender: "visitor", text, ts: Date.now() };
    c.messages.push(msg);
    c.unreadAdmin = (c.unreadAdmin || 0) + 1;
    return c;
  });
  if (!conv) return sendJson(res, 404, { error: "Conversation not found" });
  sse.notifyAdmins("new-message", { visitorId, meta: conv.meta, text, ts: Date.now() });
  sendJson(res, 200, { ok: true, messages: conv.messages });
}

async function handleAiAsk(req, res) {
  const body = await readJsonBody(req);
  const message = String(body.message || "").slice(0, 2000);
  const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
  if (!message.trim()) return sendJson(res, 400, { error: "message required" });

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return sendJson(res, 501, { error: "The AI assistant isn't configured yet. Set ANTHROPIC_API_KEY in your .env file — see README." });
  }

  const data = db.readDb();
  const p = data.portfolio;
  const context = { name: p.name, role: p.role, tagline: p.tagline, intro: p.intro, skills: p.skills, projects: p.projects };
  const system = `You are the AI assistant embedded in ${p.name}'s personal portfolio site. Speak on their behalf to visitors, warmly and briefly (under ~80 words, conversational). Use only this information: ${JSON.stringify(context)}. If you don't know something, say so honestly. If a visitor wants to hire them, point them to the contact form on the page rather than collecting details yourself.`;

  const messages = [...history.filter(m => m && m.role && m.content).slice(-10), { role: "user", content: message }];

  try {
    const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5",
        max_tokens: 500,
        system,
        messages
      })
    });
    const json = await apiRes.json();
    if (!apiRes.ok) {
      console.error("[ai] Anthropic API error:", json);
      return sendJson(res, 502, { error: "The AI assistant is temporarily unavailable." });
    }
    const text = (json.content || []).map((c) => c.text || "").join("\n").trim();
    sendJson(res, 200, { text: text || "Sorry, I couldn't put an answer together — try asking again." });
  } catch (e) {
    console.error("[ai] request failed:", e.message);
    sendJson(res, 502, { error: "The AI assistant is temporarily unavailable." });
  }
}

// --- Admin routes ---

async function handleAdminLogin(req, res) {
  const ip = clientIp(req);
  if (auth.isRateLimited(ip)) {
    return sendJson(res, 429, { error: "Too many attempts. Try again in a few minutes." });
  }
  const body = await readJsonBody(req);
  const password = String(body.password || "");
  const data = db.readDb();
  const ok = data.adminAuth && auth.verifyPassword(password, data.adminAuth.salt, data.adminAuth.hash);
  if (!ok) {
    auth.recordAttempt(ip);
    return sendJson(res, 401, { error: "Incorrect password." });
  }
  auth.clearAttempts(ip);
  const token = auth.createSession();
  auth.setSessionCookie(req, res, token);
  sendJson(res, 200, { ok: true });
}

async function handleAdminLogout(req, res) {
  const token = auth.getSessionToken(req);
  if (token) auth.destroySession(token);
  auth.clearSessionCookie(req, res);
  sendJson(res, 200, { ok: true });
}

async function handleAdminMe(req, res) {
  sendJson(res, 200, { authenticated: auth.requireAuth(req) });
}

async function handleAdminPortfolioUpdate(req, res) {
  const body = await readJsonBody(req);
  const allowed = ["name", "role", "tagline", "intro", "email", "location", "issue", "skills", "projects", "testimonials"];
  const updated = db.update((data) => {
    for (const key of allowed) {
      if (key in body) data.portfolio[key] = body[key];
    }
    return data.portfolio;
  });
  sendJson(res, 200, publicPortfolio(updated));
}

async function handleAdminConversations(req, res) {
  const data = db.readDb();
  const list = Object.entries(data.conversations)
    .map(([key, conv]) => conversationSummary(conv, key))
    .sort((a, b) => (b.lastMessage?.ts || 0) - (a.lastMessage?.ts || 0));
  sendJson(res, 200, { conversations: list });
}

async function handleAdminConversationDetail(req, res, id) {
  const conv = db.update((data) => {
    const c = data.conversations[id];
    if (c) c.unreadAdmin = 0;
    return c;
  });
  if (!conv) return sendJson(res, 404, { error: "Not found" });
  sendJson(res, 200, conv);
}

async function handleAdminReply(req, res, id) {
  const body = await readJsonBody(req);
  const text = String(body.text || "").trim().slice(0, 4000);
  if (!text) return sendJson(res, 400, { error: "Message text required" });
  const conv = db.update((data) => {
    const c = data.conversations[id];
    if (!c) return null;
    const msg = { id: crypto.randomUUID(), sender: "admin", text, ts: Date.now() };
    c.messages.push(msg);
    c.unreadVisitor = (c.unreadVisitor || 0) + 1;
    return c;
  });
  if (!conv) return sendJson(res, 404, { error: "Not found" });
  sse.notifyVisitor(id, "new-reply", { text, ts: Date.now() });
  sendJson(res, 200, conv);
}

async function handleAdminChangePassword(req, res) {
  const body = await readJsonBody(req);
  const current = String(body.current || "");
  const next = String(body.next || "");
  if (next.length < 8) return sendJson(res, 400, { error: "New password must be at least 8 characters." });
  const data = db.readDb();
  if (!data.adminAuth || !auth.verifyPassword(current, data.adminAuth.salt, data.adminAuth.hash)) {
    return sendJson(res, 401, { error: "Current password is incorrect." });
  }
  db.update((d) => { d.adminAuth = auth.hashPassword(next); });
  sendJson(res, 200, { ok: true });
}

async function handleAdminAnalytics(req, res) {
  const data = db.readDb();
  const inquiryByDay = {};
  for (const conv of Object.values(data.conversations)) {
    for (const m of conv.messages) {
      if (m.sender === "visitor") {
        const k = dayKey(m.ts);
        inquiryByDay[k] = (inquiryByDay[k] || 0) + 1;
      }
    }
  }
  sendJson(res, 200, {
    visits: data.analytics.visits,
    clicks: data.analytics.clicks,
    conversationCount: Object.keys(data.conversations).length,
    inquiryByDay
  });
}

/* ---------------------------------------------------------------
   ROUTER
----------------------------------------------------------------*/
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const { pathname } = url;
    const method = req.method;

    // CORS is intentionally NOT opened up — this server only expects to be
    // called from its own frontend, served from the same origin.

    // --- SSE streams ---
    if (method === "GET" && pathname === "/api/admin/stream") {
      if (!auth.requireAuth(req)) return sendJson(res, 401, { error: "Unauthorized" });
      return sse.addAdminClient(res);
    }
    if (method === "GET" && pathname.match(/^\/api\/visitor\/[^/]+\/stream$/)) {
      const visitorId = pathname.split("/")[3];
      return sse.addVisitorClient(visitorId, res);
    }

    // --- Public API ---
    if (method === "GET" && pathname === "/api/portfolio") return await handlePublicPortfolio(req, res);
    if (method === "POST" && pathname === "/api/track/visit") return await handleTrackVisit(req, res);
    if (method === "POST" && pathname === "/api/track/click") return await handleTrackClick(req, res);
    if (method === "POST" && pathname === "/api/visitor/start") return await handleVisitorStart(req, res);
    if (method === "POST" && pathname === "/api/ai/ask") return await handleAiAsk(req, res);

    let m = pathname.match(/^\/api\/visitor\/([^/]+)\/messages$/);
    if (m && method === "GET") return await handleVisitorMessages(req, res, m[1]);
    if (m && method === "POST") return await handleVisitorSend(req, res, m[1]);

    // --- Admin auth ---
    if (method === "POST" && pathname === "/api/admin/login") return await handleAdminLogin(req, res);
    if (method === "POST" && pathname === "/api/admin/logout") return await handleAdminLogout(req, res);
    if (method === "GET" && pathname === "/api/admin/me") return await handleAdminMe(req, res);

    // --- Admin-protected routes ---
    if (pathname.startsWith("/api/admin/")) {
      if (!auth.requireAuth(req)) return sendJson(res, 401, { error: "Unauthorized" });

      if (method === "PUT" && pathname === "/api/admin/portfolio") return await handleAdminPortfolioUpdate(req, res);
      if (method === "GET" && pathname === "/api/admin/conversations") return await handleAdminConversations(req, res);
      if (method === "POST" && pathname === "/api/admin/change-password") return await handleAdminChangePassword(req, res);
      if (method === "GET" && pathname === "/api/admin/analytics") return await handleAdminAnalytics(req, res);

      let cm = pathname.match(/^\/api\/admin\/conversations\/([^/]+)$/);
      if (cm && method === "GET") return await handleAdminConversationDetail(req, res, cm[1]);

      let rm = pathname.match(/^\/api\/admin\/conversations\/([^/]+)\/reply$/);
      if (rm && method === "POST") return await handleAdminReply(req, res, rm[1]);

      return sendJson(res, 404, { error: "Not found" });
    }

    // --- Static files (the whole frontend) ---
    if (method === "GET") return serveStatic(req, res, pathname);

    sendJson(res, 404, { error: "Not found" });
  } catch (err) {
    const status = err.statusCode || 500;
    console.error("[server] error:", err);
    sendJson(res, status, { error: status === 500 ? "Internal server error" : err.message });
  }
});

server.listen(PORT, () => {
  console.log(`Portfolio server running at http://localhost:${PORT}`);
  console.log(`Admin dashboard at http://localhost:${PORT}/admin`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.log("Note: ANTHROPIC_API_KEY is not set — the AI assistant will show a friendly error until you add one to .env.");
  }
});
