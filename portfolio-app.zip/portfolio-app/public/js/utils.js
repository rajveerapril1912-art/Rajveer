// utils.js — shared helpers

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v; // only ever used with our own trusted icon strings
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null) node.setAttribute(k, v);
  }
  for (const child of [].concat(children)) {
    if (child === null || child === undefined) continue;
    node.appendChild(typeof child === "string" ? document.createTextNode(child) : child);
  }
  return node;
}

// Every piece of user- or visitor-supplied text goes through `text()`
// (creates a text node) rather than innerHTML, so there's no stored-XSS path
// from portfolio content or chat messages.
function text(str) {
  return document.createTextNode(str == null ? "" : String(str));
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    method: options.method || "GET",
    headers: options.body ? { "Content-Type": "application/json" } : {},
    body: options.body ? JSON.stringify(options.body) : undefined,
    credentials: "same-origin"
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* no body */ }
  if (!res.ok) {
    const err = new Error((data && data.error) || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function clockTime(ts) {
  return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

function isValidEmail(v) {
  return /^\S+@\S+\.\S+$/.test(v);
}

function makeToastStack() {
  const stack = el("div", { class: "toast-stack" });
  document.body.appendChild(stack);
  return function pushToast({ title, body }) {
    const toast = el("div", { class: "toast slide-in" }, [
      el("div", { html: Icon.bell, style: "color: var(--bronze); flex-shrink:0; margin-top:2px;" }),
      el("div", {}, [
        el("strong", {}, [text(title)]),
        body ? el("div", { class: "toast-body" }, [text(body)]) : null
      ])
    ]);
    stack.appendChild(toast);
    setTimeout(() => toast.remove(), 5000);
  };
}

// Shared chat bubble + input row, used by both the visitor-facing widgets
// (site.js) and the admin inbox (admin.js).
function buildBubble({ mine, text: t, ts, colorClass, typing }) {
  const bubble = el("div", { class: "bubble" });
  if (typing) {
    bubble.appendChild(el("div", { class: "typing-dots" }, [el("span"), el("span"), el("span")]));
  } else {
    bubble.appendChild(text(t));
    if (ts) bubble.appendChild(el("div", { class: "bubble-time" }, [text(clockTime(ts))]));
  }
  return el("div", { class: "bubble-row" + (mine ? " mine " + (colorClass || "accent-color") : "") }, [bubble]);
}

function buildPanelInput({ onSend, placeholder }) {
  const textarea = el("textarea", { class: "input", placeholder, rows: "1" });
  const sendBtn = el("button", { class: "panel-send focus-ring" }, [el("span", { html: Icon.send })]);
  function trigger() {
    const val = textarea.value.trim();
    if (!val) return;
    textarea.value = "";
    onSend(val);
  }
  sendBtn.addEventListener("click", trigger);
  textarea.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); trigger(); } });
  const row = el("div", { class: "panel-input-row" }, [textarea, sendBtn]);
  row.setDisabled = (v) => { sendBtn.disabled = v; };
  return row;
}

function buildPanelHeader({ iconHtml, title, subtitle, onClose }) {
  return el("div", { class: "panel-header" }, [
    el("div", { class: "panel-header-left" }, [
      el("div", { class: "panel-icon" }, [el("span", { html: iconHtml })]),
      el("div", {}, [el("div", { class: "panel-title" }, [text(title)]), el("div", { class: "panel-subtitle" }, [text(subtitle)])])
    ]),
    el("button", { class: "panel-close focus-ring", onclick: onClose }, [el("span", { html: Icon.x })])
  ]);
}
