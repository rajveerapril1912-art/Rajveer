// site.js — renders the public portfolio and both chat widgets.

const pushToast = makeToastStack();
const app = document.getElementById("app");

let portfolio = null;
let askOpen = false;
let noteOpen = false;

/* ---------------------------------------------------------------
   BOOT
----------------------------------------------------------------*/
(async function init() {
  try {
    portfolio = await api("/api/portfolio");
  } catch (e) {
    app.appendChild(el("div", { style: "padding:40px;font-family:var(--font-body);" }, [text("Couldn't load the portfolio. Please refresh.")]));
    return;
  }
  render();
  api("/api/track/visit", { method: "POST" }).catch(() => {});
})();

function render() {
  app.innerHTML = "";
  app.appendChild(buildMasthead());
  app.appendChild(buildHero());
  app.appendChild(buildIndexSection());
  app.appendChild(buildWorkSection());
  app.appendChild(buildSaySection());
  app.appendChild(buildAboutSection());
  app.appendChild(buildFooter());
  app.appendChild(buildDock());
  app.appendChild(buildAskPanel());
  app.appendChild(buildNotePanel());
}

function goAdmin() { window.location.href = "/admin"; }

/* ---------------------------------------------------------------
   MASTHEAD
----------------------------------------------------------------*/
function buildMasthead() {
  const links = [["01", "Index", "#index"], ["02", "Work", "#work"], ["03", "Say", "#say"], ["04", "About", "#about"]];
  const nav = el("div", { class: "nav-links" }, [
    ...links.map(([n, label, href]) => el("a", { href }, [el("span", {}, [text(n)]), text(" " + label)])),
    el("button", { class: "studio-link focus-ring", onclick: goAdmin }, [el("span", { html: Icon.lock }), text("Studio Desk")])
  ]);
  return el("header", { class: "masthead" }, [
    el("div", { class: "masthead-inner" }, [
      el("a", { href: "#top", class: "wordmark" }, [text(portfolio.name)]),
      nav
    ])
  ]);
}

/* ---------------------------------------------------------------
   HERO
----------------------------------------------------------------*/
function buildHero() {
  return el("section", { id: "top", class: "hero fade-up" }, [
    el("div", { class: "eyebrow" }, [text("Portfolio — " + portfolio.issue)]),
    el("h1", {}, [text(portfolio.tagline)]),
    el("p", {}, [text(portfolio.intro)]),
    el("div", { class: "hero-actions" }, [
      el("a", { href: "#work", style: "text-decoration:none;" }, [
        el("button", { class: "btn-primary focus-ring" }, [text("See the work "), el("span", { html: Icon.chevronRight, style: "display:flex;" })])
      ]),
      el("span", { style: "font-family:var(--font-mono);font-size:12px;color:var(--ink-faint);" }, [text(portfolio.location)])
    ])
  ]);
}

/* ---------------------------------------------------------------
   INDEX / SKILLS
----------------------------------------------------------------*/
function buildIndexSection() {
  const rows = (portfolio.skills || []).map((s, i) =>
    el("div", { class: "skill-row" }, [
      el("span", { class: "skill-num" }, [text(String(i + 1).padStart(2, "0"))]),
      el("span", { class: "skill-name" }, [text(s.name)]),
      el("span", { class: "skill-dots" }),
      el("span", { class: "skill-detail" }, [text(s.detail)])
    ])
  );
  return el("section", { id: "index", class: "index-section" }, [
    el("div", { class: "index-inner" }, [
      el("div", { class: "eyebrow" }, [text("Contents")]),
      el("h2", {}, [text("Skills on the masthead")]),
      el("div", {}, rows)
    ])
  ]);
}

/* ---------------------------------------------------------------
   WORK
----------------------------------------------------------------*/
function buildProjectThumb(p, height) {
  const wrap = el("div", { class: "project-thumb", style: height ? `height:${height}px;` : "" });
  if (p.imageUrl) {
    const img = el("img", { src: p.imageUrl, alt: p.title });
    img.addEventListener("error", () => {
      wrap.innerHTML = "";
      wrap.appendChild(el("span", { class: "placeholder" }, [text((p.title || "?").slice(0, 1))]));
    });
    wrap.appendChild(img);
  } else {
    wrap.appendChild(el("span", { class: "placeholder" }, [text((p.title || "?").slice(0, 1))]));
  }
  return wrap;
}

function openProjectModal(p) {
  api("/api/track/click", { method: "POST", body: { projectId: p.id } }).catch(() => {});
  const backdrop = el("div", { class: "modal-backdrop", onclick: () => backdrop.remove() }, [
    el("div", { class: "modal-card pop-in scrollbar-thin", onclick: (e) => e.stopPropagation() }, [
      el("button", { class: "modal-close", onclick: () => backdrop.remove() }, [el("span", { html: Icon.x })]),
      buildProjectThumb(p, 260),
      el("div", { class: "modal-body" }, [
        el("span", { class: "eyebrow" }, [text(p.category + " · " + p.year)]),
        el("h3", {}, [text(p.title)]),
        el("p", {}, [text(p.description)]),
        el("div", { class: "tag-row", style: "margin-top:14px;" }, (p.tags || []).map(t => el("span", { class: "tag alt" }, [text(t)])))
      ])
    ])
  ]);
  document.body.appendChild(backdrop);
}

function buildWorkSection() {
  const cards = (portfolio.projects || []).map(p =>
    el("button", { class: "project-card focus-ring", onclick: () => openProjectModal(p) }, [
      buildProjectThumb(p),
      el("div", { class: "project-row-top" }, [
        el("span", { style: "font-family:var(--font-mono);font-size:11px;color:var(--bronze);" }, [text(p.category)]),
        el("span", { style: "font-family:var(--font-mono);font-size:11px;color:var(--ink-faint);" }, [text(p.year)])
      ]),
      el("h3", {}, [text(p.title)]),
      el("p", {}, [text(p.description)]),
      el("div", { class: "tag-row" }, (p.tags || []).map(t => el("span", { class: "tag" }, [text(t)])))
    ])
  );
  return el("section", { id: "work", class: "work-inner" }, [
    el("div", { class: "eyebrow" }, [text("Selected Work")]),
    el("h2", {}, [text("Recent projects")]),
    el("div", { class: "project-grid" }, cards)
  ]);
}

/* ---------------------------------------------------------------
   TESTIMONIALS
----------------------------------------------------------------*/
function buildSaySection() {
  const items = portfolio.testimonials || [];
  if (!items.length) return el("div");
  const cards = items.map(t =>
    el("div", { class: "testimonial-card" }, [
      el("span", { html: Icon.quote, style: "color:var(--bronze);opacity:0.6;" }),
      el("p", { class: "testimonial-quote" }, [text('"' + t.quote + '"')]),
      el("div", {}, [
        el("div", { class: "testimonial-name" }, [text(t.name)]),
        el("div", { class: "testimonial-role" }, [text(t.role)])
      ])
    ])
  );
  return el("section", { id: "say", class: "say-section" }, [
    el("div", { class: "say-inner" }, [
      el("div", { class: "eyebrow" }, [text("What they say")]),
      el("h2", {}, [text("From past clients")]),
      el("div", { class: "testimonial-grid" }, cards)
    ])
  ]);
}

/* ---------------------------------------------------------------
   ABOUT + FOOTER
----------------------------------------------------------------*/
function buildAboutSection() {
  return el("section", { id: "about", class: "about-section" }, [
    el("div", { class: "about-inner" }, [
      el("div", { class: "eyebrow dark" }, [text("About")]),
      el("h2", {}, [text(portfolio.role)]),
      el("p", {}, [text(portfolio.intro)]),
      el("div", { class: "about-email" }, [el("span", { html: Icon.mail, style: "color:var(--bronze);" }), text(portfolio.email)])
    ])
  ]);
}

function buildFooter() {
  return el("footer", { class: "site-footer" }, [
    el("div", { class: "footer-inner" }, [
      el("span", {}, [text(`© ${new Date().getFullYear()} ${portfolio.name} — ${portfolio.issue}`)]),
      el("button", { class: "focus-ring", onclick: goAdmin }, [el("span", { html: Icon.lock }), text("Studio Desk")])
    ])
  ]);
}

/* ---------------------------------------------------------------
   DOCK
----------------------------------------------------------------*/
function buildDock() {
  return el("div", { class: "dock" }, [
    el("button", { class: "dock-btn note focus-ring", onclick: () => togglePanel("note") }, [el("span", { html: Icon.message }), text("Leave a Note")]),
    el("button", { class: "dock-btn ask focus-ring", onclick: () => togglePanel("ask") }, [el("span", { html: Icon.sparkles, style: "color:var(--bronze);" }), text("Ask the Studio")])
  ]);
}

function togglePanel(which) {
  if (which === "ask") { askOpen = !askOpen; noteOpen = false; }
  else { noteOpen = !noteOpen; askOpen = false; }
  document.getElementById("ask-panel-wrap").classList.toggle("open", askOpen);
  document.getElementById("note-panel-wrap").classList.toggle("open", noteOpen);
}

/* ---------------------------------------------------------------
   ASK THE STUDIO (AI assistant)
----------------------------------------------------------------*/
function buildAskPanel() {
  const body = el("div", { class: "panel-body scrollbar-thin" });
  const history = []; // { role, content }
  let loading = false;

  function addMsg({ mine, text: t, typing }) {
    const row = buildBubble({ mine, text: t, colorClass: "bronze-color", typing });
    body.appendChild(row);
    body.scrollTop = body.scrollHeight;
    return row;
  }

  addMsg({ mine: false, text: `Hi — I can talk you through ${portfolio.name.split(" ")[0]}'s work and skills. Ask me anything, like "what's your experience with branding?"` });

  const inputRow = buildPanelInput({
    placeholder: "Ask about a project or skill…",
    onSend: async (val) => {
      if (loading) return;
      addMsg({ mine: true, text: val });
      history.push({ role: "user", content: val });
      loading = true;
      inputRow.setDisabled(true);
      const typingRow = addMsg({ mine: false, typing: true });
      try {
        const res = await api("/api/ai/ask", { method: "POST", body: { message: val, history: history.slice(0, -1) } });
        typingRow.remove();
        addMsg({ mine: false, text: res.text });
        history.push({ role: "assistant", content: res.text });
      } catch (e) {
        typingRow.remove();
        addMsg({ mine: false, text: e.message || "I'm having trouble connecting right now. Feel free to leave a note instead." });
      } finally {
        loading = false;
        inputRow.setDisabled(false);
      }
    }
  });

  const panel = el("div", { class: "panel pop-in" }, [
    buildPanelHeader({ iconHtml: Icon.sparkles, title: "Ask the Studio", subtitle: "AI assistant · answers from the portfolio", onClose: () => togglePanel("ask") }),
    body,
    inputRow
  ]);
  return el("div", { id: "ask-panel-wrap", class: "panel-wrap" }, [panel]);
}

/* ---------------------------------------------------------------
   LEAVE A NOTE (visitor inquiry, backed by real conversation + SSE)
----------------------------------------------------------------*/
function buildNotePanel() {
  const wrap = el("div", { id: "note-panel-wrap", class: "panel-wrap" });
  const existingId = localStorage.getItem("visitorId");

  if (existingId) {
    wrap.appendChild(el("div", { class: "panel pop-in", style: "align-items:center;justify-content:center;" }, [
      el("span", { html: Icon.loader, class: "pulse-dot", style: "color:var(--accent);margin:auto;" })
    ]));
    api(`/api/visitor/${existingId}/messages`)
      .then(res => renderChat(existingId, res.messages))
      .catch(() => renderGate());
  } else {
    renderGate();
  }

  function renderGate() {
    wrap.innerHTML = "";
    let err = "";
    const nameInput = el("input", { class: "input focus-ring", placeholder: "Your name" });
    const emailInput = el("input", { class: "input focus-ring", type: "email", placeholder: "you@email.com" });
    const phoneInput = el("input", { class: "input focus-ring", placeholder: "+1 555 000 0000" });
    const errBox = el("div", { style: "color:var(--danger);font-size:12.5px;margin-bottom:12px;font-family:var(--font-body);" });

    const submit = async () => {
      const email = emailInput.value.trim();
      const phone = phoneInput.value.trim();
      if (!isValidEmail(email)) { errBox.textContent = "Enter a valid email so I can reply to you."; return; }
      if (!phone) { errBox.textContent = "Add a phone number too — it helps for quick follow-ups."; return; }
      errBox.textContent = "";
      try {
        const res = await api("/api/visitor/start", { method: "POST", body: { name: nameInput.value.trim(), email, phone } });
        localStorage.setItem("visitorId", res.visitorId);
        renderChat(res.visitorId, res.messages);
      } catch (e) {
        errBox.textContent = e.message;
      }
    };

    const panel = el("div", { class: "panel pop-in" }, [
      buildPanelHeader({ iconHtml: Icon.message, title: "Leave a Note", subtitle: "A quick line before we chat", onClose: () => togglePanel("note") }),
      el("div", { class: "panel-gate scrollbar-thin" }, [
        el("p", { style: "font-family:var(--font-body);font-size:13.5px;color:var(--ink-soft);margin-top:0;margin-bottom:18px;line-height:1.6;" }, [
          text("Share how to reach you — messages are saved so we can pick the conversation back up.")
        ]),
        el("label", { class: "field" }, [el("div", { class: "field-label" }, [text("Name (optional)")]), nameInput]),
        el("label", { class: "field" }, [el("div", { class: "field-label" }, [text("Email")]), emailInput]),
        el("label", { class: "field" }, [el("div", { class: "field-label" }, [text("Phone")]), phoneInput]),
        errBox,
        el("button", { class: "btn-primary focus-ring", style: "width:100%;justify-content:center;", onclick: submit }, [text("Start the conversation")]),
        el("div", { style: "font-family:var(--font-mono);font-size:10.5px;color:var(--ink-faint);margin-top:14px;line-height:1.6;" }, [
          text("Your details are stored so the studio can view and reply to your message later.")
        ])
      ])
    ]);
    wrap.appendChild(panel);
  }

  function renderChat(visitorId, initialMessages) {
    wrap.innerHTML = "";
    const body = el("div", { class: "panel-body scrollbar-thin" });
    (initialMessages || []).forEach(m => body.appendChild(buildBubble({ mine: m.sender === "visitor", text: m.text, ts: m.ts, colorClass: "accent-color" })));

    const inputRow = buildPanelInput({
      placeholder: "Write your message…",
      onSend: async (val) => {
        inputRow.setDisabled(true);
        try {
          await api(`/api/visitor/${visitorId}/messages`, { method: "POST", body: { text: val } });
          body.appendChild(buildBubble({ mine: true, text: val, ts: Date.now(), colorClass: "accent-color" }));
          body.scrollTop = body.scrollHeight;
        } catch (e) {
          pushToast({ title: "Couldn't send", body: e.message });
        } finally {
          inputRow.setDisabled(false);
        }
      }
    });

    const panel = el("div", { class: "panel pop-in" }, [
      buildPanelHeader({ iconHtml: Icon.message, title: "Leave a Note", subtitle: "Direct line to the studio", onClose: () => togglePanel("note") }),
      body,
      inputRow
    ]);
    wrap.appendChild(panel);
    body.scrollTop = body.scrollHeight;

    // Real-time replies via Server-Sent Events — no polling.
    const stream = new EventSource(`/api/visitor/${visitorId}/stream`);
    stream.addEventListener("new-reply", (evt) => {
      const data = JSON.parse(evt.data);
      body.appendChild(buildBubble({ mine: false, text: data.text, ts: data.ts, colorClass: "accent-color" }));
      body.scrollTop = body.scrollHeight;
      if (!noteOpen) pushToast({ title: "New reply", body: data.text.slice(0, 80) });
      if (typeof Notification !== "undefined" && Notification.permission === "granted" && document.hidden) {
        try { new Notification("New reply", { body: data.text.slice(0, 100) }); } catch (e) {}
      }
    });
  }

  return wrap;
}
