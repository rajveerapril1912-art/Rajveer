// admin.js — Studio Desk admin dashboard.

const pushToast = makeToastStack();
const app = document.getElementById("app");

(async function boot() {
  try {
    const me = await api("/api/admin/me");
    if (me.authenticated) renderDashboard();
    else renderLogin();
  } catch (e) {
    renderLogin();
  }
})();

/* ---------------------------------------------------------------
   LOGIN
----------------------------------------------------------------*/
function renderLogin() {
  app.innerHTML = "";
  const passwordInput = el("input", { type: "password", class: "focus-ring" });
  const errBox = el("div", { style: "color:#E08B76;font-size:12.5px;margin-bottom:10px;font-family:var(--font-body);" });
  const submitBtn = el("button", { class: "btn-primary focus-ring", style: "width:100%;justify-content:center;margin-top:6px;" }, [
    el("span", { html: Icon.lock }), text(" Enter Studio Desk")
  ]);

  const submit = async () => {
    submitBtn.disabled = true;
    errBox.textContent = "";
    try {
      await api("/api/admin/login", { method: "POST", body: { password: passwordInput.value } });
      renderDashboard();
    } catch (e) {
      errBox.textContent = e.message || "That password doesn't match. Try again.";
    } finally {
      submitBtn.disabled = false;
    }
  };
  submitBtn.addEventListener("click", submit);
  passwordInput.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });

  const card = el("div", { class: "admin-login-card fade-up" }, [
    el("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:20px;" }, [
      el("div", { style: "width:38px;height:38px;border-radius:10px;background:var(--dark);display:flex;align-items:center;justify-content:center;color:var(--bronze);" }, [el("span", { html: Icon.shield })]),
      el("div", {}, [
        el("div", { style: "font-family:var(--font-display);font-size:19px;font-weight:600;color:var(--paper);" }, [text("Studio Desk")]),
        el("div", { style: "font-family:var(--font-mono);font-size:10.5px;color:rgba(238,235,227,0.5);" }, [text("Admin access only")])
      ])
    ]),
    el("label", {}, [el("div", { class: "field-label" }, [text("Password")]), passwordInput]),
    errBox,
    submitBtn,
    el("button", { class: "focus-ring", style: "background:transparent;border:none;color:rgba(238,235,227,0.5);font-family:var(--font-mono);font-size:11.5px;cursor:pointer;margin-top:16px;width:100%;text-align:center;", onclick: () => window.location.href = "/" }, [
      text("← Back to portfolio")
    ])
  ]);
  app.appendChild(el("div", { class: "admin-login-wrap" }, [card]));
  passwordInput.focus();
}

/* ---------------------------------------------------------------
   DASHBOARD SHELL
----------------------------------------------------------------*/
function renderDashboard() {
  app.innerHTML = "";
  let activeTab = "inbox";
  const tabs = [
    ["inbox", "Inbox", Icon.inbox],
    ["editor", "Portfolio", Icon.user],
    ["analytics", "Analytics", Icon.barChart],
    ["settings", "Settings", Icon.settings]
  ];

  const mainHeader = el("div", { class: "admin-main-header" }, [text("Inbox")]);
  const mainBody = el("div", { class: "admin-main-body", style: "flex:1;display:flex;flex-direction:column;min-height:0;" });
  const tabButtons = {};

  function selectTab(key) {
    activeTab = key;
    Object.entries(tabButtons).forEach(([k, btn]) => btn.classList.toggle("active", k === key));
    mainHeader.textContent = tabs.find(t => t[0] === key)[1];
    mainBody.innerHTML = "";
    if (key === "inbox") mainBody.appendChild(buildInboxTab());
    if (key === "editor") mainBody.appendChild(buildEditorTab());
    if (key === "analytics") mainBody.appendChild(buildAnalyticsTab());
    if (key === "settings") mainBody.appendChild(buildSettingsTab());
  }

  const sidebar = el("div", { class: "admin-sidebar" }, [
    el("div", { style: "display:flex;align-items:center;gap:8px;padding:0 8px 22px;" }, [
      el("span", { style: "width:9px;height:9px;border-radius:50%;background:var(--bronze);display:inline-block;", class: "pulse-dot" }),
      el("span", { style: "font-family:var(--font-mono);font-size:10.5px;color:rgba(238,235,227,0.6);" }, [text("Live · Studio Desk")])
    ]),
    ...tabs.map(([key, label, icon]) => {
      const btn = el("button", { class: "tab-btn focus-ring", onclick: () => selectTab(key) }, [el("span", { html: icon }), text(label)]);
      tabButtons[key] = btn;
      return btn;
    }),
    el("div", { style: "flex:1;" }),
    el("button", { class: "tab-btn focus-ring", onclick: () => window.location.href = "/" }, [el("span", { html: Icon.externalLink }), text("View site")]),
    el("button", { class: "tab-btn focus-ring", style: "color:rgba(224,139,118,0.85);", onclick: async () => { await api("/api/admin/logout", { method: "POST" }).catch(() => {}); renderLogin(); } }, [el("span", { html: Icon.logout }), text("Log out")])
  ]);

  app.appendChild(el("div", { class: "admin-shell" }, [
    sidebar,
    el("div", { class: "admin-main" }, [mainHeader, mainBody])
  ]));

  if (typeof Notification !== "undefined" && Notification.permission === "default") {
    Notification.requestPermission();
  }

  selectTab("inbox");
}

/* ---------------------------------------------------------------
   INBOX
----------------------------------------------------------------*/
function buildInboxTab() {
  const layout = el("div", { class: "inbox-layout" });
  const list = el("div", { class: "inbox-list scrollbar-thin" });
  const threadArea = el("div", { class: "inbox-thread" }, [el("div", { class: "empty-state" }, [text("Select a conversation to reply")])]);
  layout.appendChild(list);
  layout.appendChild(threadArea);

  let selectedId = null;
  let stream = null;

  async function loadList() {
    const { conversations } = await api("/api/admin/conversations");
    list.innerHTML = "";
    if (conversations.length === 0) {
      list.appendChild(el("div", { style: "padding:24px;font-family:var(--font-body);font-size:13px;color:var(--ink-faint);" }, [
        text("No messages yet. New inquiries will show up here in real time.")
      ]));
      return;
    }
    conversations.forEach(c => {
      const item = el("button", { class: "inbox-item focus-ring" + (c.id === selectedId ? " active" : ""), onclick: () => openConversation(c.id) }, [
        el("div", { class: "inbox-item-top" }, [
          el("span", { style: "font-family:var(--font-body);font-weight:600;font-size:13.5px;color:var(--ink);" }, [text(c.meta?.name || "Visitor")]),
          c.unreadAdmin > 0 ? el("span", { class: "inbox-unread-badge" }, [text(String(c.unreadAdmin))]) : null
        ]),
        el("div", { style: "font-family:var(--font-mono);font-size:10.5px;color:var(--ink-faint);margin-top:2px;" }, [text(c.meta?.email || "")]),
        el("div", { style: "font-family:var(--font-body);font-size:12px;color:var(--ink-soft);margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" }, [text(c.lastMessage?.text || "")]),
        el("div", { style: "font-family:var(--font-mono);font-size:9.5px;color:var(--ink-faint);margin-top:4px;" }, [text(c.lastMessage ? timeAgo(c.lastMessage.ts) : "")])
      ]);
      list.appendChild(item);
    });
  }

  async function openConversation(id) {
    selectedId = id;
    const conv = await api(`/api/admin/conversations/${id}`);
    threadArea.innerHTML = "";
    const body = el("div", { class: "panel-body scrollbar-thin", style: "flex:1;" });
    conv.messages.forEach(m => body.appendChild(buildBubble({ mine: m.sender === "admin", text: m.text, ts: m.ts, colorClass: "accent-color" })));

    const inputRow = buildPanelInput({
      placeholder: "Type your reply…",
      onSend: async (val) => {
        inputRow.setDisabled(true);
        try {
          await api(`/api/admin/conversations/${id}/reply`, { method: "POST", body: { text: val } });
          body.appendChild(buildBubble({ mine: true, text: val, ts: Date.now(), colorClass: "accent-color" }));
          body.scrollTop = body.scrollHeight;
        } catch (e) {
          pushToast({ title: "Couldn't send", body: e.message });
        } finally {
          inputRow.setDisabled(false);
        }
      }
    });

    threadArea.appendChild(el("div", { class: "inbox-thread-header" }, [
      el("div", { style: "font-family:var(--font-display);font-weight:600;font-size:16px;color:var(--ink);" }, [text(conv.meta.name)]),
      el("div", { class: "inbox-thread-meta" }, [
        el("span", { style: "display:flex;align-items:center;gap:4px;" }, [el("span", { html: Icon.mail }), text(conv.meta.email)]),
        el("span", { style: "display:flex;align-items:center;gap:4px;" }, [el("span", { html: Icon.phone }), text(conv.meta.phone)])
      ])
    ]));
    threadArea.appendChild(body);
    threadArea.appendChild(inputRow);
    body.scrollTop = body.scrollHeight;
    loadList();
  }

  loadList();

  // Real-time: new visitor messages push straight to the admin, no polling.
  stream = new EventSource("/api/admin/stream");
  stream.addEventListener("new-message", (evt) => {
    const data = JSON.parse(evt.data);
    pushToast({ title: "New inquiry from " + (data.meta?.name || "a visitor"), body: data.text.slice(0, 80) });
    if (typeof Notification !== "undefined" && Notification.permission === "granted") {
      try { new Notification("New portfolio inquiry", { body: (data.meta?.name || "A visitor") + ": " + data.text.slice(0, 100) }); } catch (e) {}
    }
    if (data.visitorId === selectedId) {
      openConversation(selectedId);
    } else {
      loadList();
    }
  });

  const cleanupWrap = el("div", { style: "display:contents;" }, [layout]);
  // When this tab is torn down (switching tabs), close the SSE connection.
  const observer = new MutationObserver(() => {
    if (!document.body.contains(layout)) { stream.close(); observer.disconnect(); }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  return layout;
}

/* ---------------------------------------------------------------
   PORTFOLIO EDITOR
----------------------------------------------------------------*/
function buildEditorTab() {
  const container = el("div", { class: "admin-tab-body scrollbar-thin" });
  container.appendChild(el("div", { style: "font-family:var(--font-body);font-size:13px;color:var(--ink-faint);" }, [text("Loading…")]));

  api("/api/portfolio").then(draft => {
    container.innerHTML = "";

    const nameInput = el("input", { class: "input focus-ring", value: draft.name });
    const roleInput = el("input", { class: "input focus-ring", value: draft.role });
    const taglineInput = el("textarea", { class: "input focus-ring", style: "min-height:70px;" }, [text(draft.tagline)]);
    const introInput = el("textarea", { class: "input focus-ring", style: "min-height:90px;" }, [text(draft.intro)]);
    const emailInput = el("input", { class: "input focus-ring", value: draft.email });
    const locationInput = el("input", { class: "input focus-ring", value: draft.location });

    const field = (label, node) => el("label", { class: "field" }, [el("div", { class: "field-label" }, [text(label)]), node]);

    container.appendChild(el("div", { class: "section-title", style: "margin-top:0;" }, [text("Basics")]));
    container.appendChild(field("Name", nameInput));
    container.appendChild(field("Role / headline", roleInput));
    container.appendChild(field("Tagline (hero headline)", taglineInput));
    container.appendChild(field("Intro / bio", introInput));
    container.appendChild(el("div", { style: "display:flex;gap:12px;" }, [
      el("div", { style: "flex:1;" }, [field("Contact email", emailInput)]),
      el("div", { style: "flex:1;" }, [field("Location", locationInput)])
    ]));

    // --- Skills ---
    container.appendChild(el("div", { class: "section-title" }, [text("Skills")]));
    const skillsList = el("div");
    let skills = draft.skills.map(s => ({ ...s }));
    function renderSkills() {
      skillsList.innerHTML = "";
      skills.forEach((s, i) => {
        const nameEl = el("input", { class: "input focus-ring", style: "font-weight:600;", value: s.name });
        const detailEl = el("input", { class: "input focus-ring", style: "margin-top:8px;", value: s.detail });
        nameEl.addEventListener("input", () => skills[i].name = nameEl.value);
        detailEl.addEventListener("input", () => skills[i].detail = detailEl.value);
        const removeBtn = el("button", { class: "icon-btn focus-ring", onclick: () => { skills.splice(i, 1); renderSkills(); } }, [el("span", { html: Icon.trash, style: "color:var(--danger);" })]);
        skillsList.appendChild(el("div", { class: "entry-card" }, [
          el("div", { class: "entry-card-row" }, [nameEl, removeBtn]),
          detailEl
        ]));
      });
    }
    renderSkills();
    container.appendChild(skillsList);
    container.appendChild(el("button", { class: "btn-ghost focus-ring", onclick: () => { skills.push({ id: "s" + uid(), name: "New skill", detail: "" }); renderSkills(); } }, [el("span", { html: Icon.plus }), text("Add skill")]));

    // --- Projects ---
    container.appendChild(el("div", { class: "section-title" }, [text("Projects")]));
    const projectsList = el("div");
    let projects = draft.projects.map(p => ({ ...p, tags: [...(p.tags || [])] }));
    function renderProjects() {
      projectsList.innerHTML = "";
      projects.forEach((p, i) => {
        const titleEl = el("input", { class: "input focus-ring", style: "font-weight:600;", value: p.title });
        const categoryEl = el("input", { class: "input focus-ring", value: p.category });
        const yearEl = el("input", { class: "input focus-ring", style: "max-width:100px;", value: p.year });
        const descEl = el("textarea", { class: "input focus-ring", style: "min-height:60px;" }, [text(p.description)]);
        const tagsEl = el("input", { class: "input focus-ring", value: (p.tags || []).join(", ") });
        const imageEl = el("input", { class: "input focus-ring", value: p.imageUrl || "", placeholder: "Image URL (paste a link to your project image)" });
        const preview = el("img", { src: p.imageUrl || "", style: "width:44px;height:44px;border-radius:8px;object-fit:cover;flex-shrink:0;" + (p.imageUrl ? "" : "display:none;") });
        preview.addEventListener("error", () => preview.style.display = "none");

        titleEl.addEventListener("input", () => projects[i].title = titleEl.value);
        categoryEl.addEventListener("input", () => projects[i].category = categoryEl.value);
        yearEl.addEventListener("input", () => projects[i].year = yearEl.value);
        descEl.addEventListener("input", () => projects[i].description = descEl.value);
        tagsEl.addEventListener("input", () => projects[i].tags = tagsEl.value.split(",").map(t => t.trim()).filter(Boolean));
        imageEl.addEventListener("input", () => {
          projects[i].imageUrl = imageEl.value;
          preview.src = imageEl.value;
          preview.style.display = imageEl.value ? "" : "none";
        });

        const removeBtn = el("button", { class: "icon-btn focus-ring", onclick: () => { projects.splice(i, 1); renderProjects(); } }, [el("span", { html: Icon.trash, style: "color:var(--danger);" })]);

        projectsList.appendChild(el("div", { class: "entry-card" }, [
          el("div", { class: "entry-card-row" }, [titleEl, removeBtn]),
          el("div", { class: "entry-card-row" }, [categoryEl, yearEl]),
          el("div", { style: "margin-bottom:8px;" }, [descEl]),
          el("div", { style: "margin-bottom:8px;" }, [tagsEl]),
          el("div", { style: "display:flex;gap:10px;align-items:center;" }, [
            el("div", { style: "flex:1;display:flex;align-items:center;gap:8px;" }, [el("span", { html: Icon.image, style: "color:var(--ink-faint);flex-shrink:0;" }), imageEl]),
            preview
          ])
        ]));
      });
    }
    renderProjects();
    container.appendChild(projectsList);
    container.appendChild(el("button", { class: "btn-ghost focus-ring", onclick: () => { projects.push({ id: "p" + uid(), title: "New project", category: "Category", year: String(new Date().getFullYear()), description: "", tags: [], imageUrl: "" }); renderProjects(); } }, [el("span", { html: Icon.plus }), text("Add project")]));

    // --- Testimonials ---
    container.appendChild(el("div", { class: "section-title" }, [text("Testimonials")]));
    const testimonialsList = el("div");
    let testimonials = (draft.testimonials || []).map(t => ({ ...t }));
    function renderTestimonials() {
      testimonialsList.innerHTML = "";
      testimonials.forEach((t, i) => {
        const quoteEl = el("textarea", { class: "input focus-ring", style: "min-height:60px;" }, [text(t.quote)]);
        const nameEl = el("input", { class: "input focus-ring", value: t.name });
        const roleEl = el("input", { class: "input focus-ring", value: t.role });
        quoteEl.addEventListener("input", () => testimonials[i].quote = quoteEl.value);
        nameEl.addEventListener("input", () => testimonials[i].name = nameEl.value);
        roleEl.addEventListener("input", () => testimonials[i].role = roleEl.value);
        const removeBtn = el("button", { class: "icon-btn focus-ring", onclick: () => { testimonials.splice(i, 1); renderTestimonials(); } }, [el("span", { html: Icon.trash, style: "color:var(--danger);" })]);
        testimonialsList.appendChild(el("div", { class: "entry-card" }, [
          el("div", { class: "entry-card-row" }, [quoteEl, removeBtn]),
          el("div", { class: "entry-card-row", style: "margin-bottom:0;" }, [nameEl, roleEl])
        ]));
      });
    }
    renderTestimonials();
    container.appendChild(testimonialsList);
    container.appendChild(el("button", { class: "btn-ghost focus-ring", onclick: () => { testimonials.push({ id: "t" + uid(), quote: "", name: "Client name", role: "Role, company" }); renderTestimonials(); } }, [el("span", { html: Icon.plus }), text("Add testimonial")]));

    // --- Save ---
    const saveBtn = el("button", { class: "btn-primary focus-ring", onclick: async () => {
      saveBtn.disabled = true;
      saveBtn.textContent = "Saving…";
      try {
        await api("/api/admin/portfolio", { method: "PUT", body: {
          name: nameInput.value, role: roleInput.value, tagline: taglineInput.value, intro: introInput.value,
          email: emailInput.value, location: locationInput.value, skills, projects, testimonials
        } });
        pushToast({ title: "Portfolio saved", body: "Your changes are live." });
      } catch (e) {
        pushToast({ title: "Save failed", body: e.message });
      } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = "";
        saveBtn.appendChild(el("span", { html: Icon.save }));
        saveBtn.appendChild(text(" Save changes"));
      }
    } }, [el("span", { html: Icon.save }), text(" Save changes")]);

    container.appendChild(el("div", { style: "margin-top:28px;position:sticky;bottom:0;background:var(--surface);padding-top:14px;padding-bottom:6px;" }, [saveBtn]));
  });

  return container;
}

/* ---------------------------------------------------------------
   ANALYTICS
----------------------------------------------------------------*/
function buildBarChart(data, key, color) {
  const max = Math.max(...data.map(d => d[key]), 1);
  return el("div", { class: "bar-chart" }, data.map(d =>
    el("div", { class: "bar-chart-col" }, [
      el("div", { class: "bar-chart-bar", style: `height:${Math.max((d[key] / max) * 100, 2)}%;background:${color};` }),
      el("div", { class: "bar-chart-label" }, [text(d.label)])
    ])
  ));
}

function buildAnalyticsTab() {
  const container = el("div", { class: "admin-tab-body scrollbar-thin" });
  container.appendChild(el("div", { style: "font-family:var(--font-body);font-size:13px;color:var(--ink-faint);" }, [text("Loading…")]));

  api("/api/admin/analytics").then(({ visits, clicks, conversationCount, inquiryByDay }) => {
    container.innerHTML = "";
    const days = [];
    for (let i = 6; i >= 0; i--) days.push(new Date(Date.now() - i * 86400000).toISOString().slice(0, 10));

    const totalInquiries = Object.values(inquiryByDay).reduce((a, b) => a + b, 0);
    container.appendChild(el("div", { class: "stat-row" }, [
      buildStatCard("Total visits", visits.total || 0, Icon.eye),
      buildStatCard("Conversations", conversationCount, Icon.message),
      buildStatCard("Messages from visitors", totalInquiries, Icon.inbox)
    ]));

    container.appendChild(el("div", { class: "section-title", style: "margin-top:0;" }, [text("Visits — last 7 days")]));
    container.appendChild(buildBarChart(days.map(d => ({ label: d.slice(5), visits: visits.byDay?.[d] || 0 })), "visits", "var(--accent)"));

    container.appendChild(el("div", { class: "section-title" }, [text("Inquiries — last 7 days")]));
    container.appendChild(buildBarChart(days.map(d => ({ label: d.slice(5), inquiries: inquiryByDay[d] || 0 })), "inquiries", "var(--bronze)"));

    container.appendChild(el("div", { class: "section-title" }, [text("Most-viewed projects")]));
    api("/api/portfolio").then(p => {
      const rankData = (p.projects || []).map(proj => ({ name: proj.title, clicks: clicks[proj.id] || 0 })).sort((a, b) => b.clicks - a.clicks);
      if (rankData.length === 0 || rankData.every(r => r.clicks === 0)) {
        container.appendChild(el("div", { style: "font-family:var(--font-body);font-size:13px;color:var(--ink-faint);" }, [text("No project clicks recorded yet.")]));
        return;
      }
      const max = Math.max(...rankData.map(r => r.clicks), 1);
      rankData.forEach(r => {
        container.appendChild(el("div", { class: "project-rank-row" }, [
          el("div", { class: "project-rank-top" }, [el("span", {}, [text(r.name)]), el("span", { style: "font-family:var(--font-mono);" }, [text(String(r.clicks))])]),
          el("div", { class: "project-rank-track" }, [el("div", { class: "project-rank-fill", style: `width:${(r.clicks / max) * 100}%;` })])
        ]));
      });
    });
  });

  return container;
}

function buildStatCard(label, value, icon) {
  return el("div", { class: "stat-card" }, [
    el("div", { class: "stat-card-label" }, [el("span", { html: icon }), text(label)]),
    el("div", { class: "stat-card-value" }, [text(String(value))])
  ]);
}

/* ---------------------------------------------------------------
   SETTINGS
----------------------------------------------------------------*/
function buildSettingsTab() {
  const container = el("div", { class: "admin-tab-body scrollbar-thin", style: "max-width:480px;" });

  container.appendChild(el("div", { class: "section-title", style: "margin-top:0;" }, [text("Notifications")]));
  container.appendChild(el("p", { style: "font-family:var(--font-body);font-size:13px;color:var(--ink-soft);line-height:1.6;" }, [
    text("Browser notifications alert you the moment a visitor sends a message, even in another tab.")
  ]));
  const status = typeof Notification !== "undefined" ? Notification.permission : "unsupported";
  const statusRow = el("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:20px;" }, [
    el("span", { style: "font-family:var(--font-mono);font-size:12px;color:var(--ink-soft);" }, [text("Status: "), el("b", { style: `color:${status === "granted" ? "var(--accent)" : "var(--bronze)"};` }, [text(status)])])
  ]);
  if (status !== "granted" && status !== "unsupported") {
    statusRow.appendChild(el("button", { class: "btn-ghost focus-ring", onclick: async () => { await Notification.requestPermission(); buildSettingsTab_refresh(); } }, [text("Enable")]));
  }
  container.appendChild(statusRow);

  function buildSettingsTab_refresh() {
    container.parentElement.replaceChild(buildSettingsTab(), container);
  }

  container.appendChild(el("div", { class: "section-title" }, [text("Change password")]));
  const currentInput = el("input", { type: "password", class: "input focus-ring" });
  const nextInput = el("input", { type: "password", class: "input focus-ring" });
  const confirmInput = el("input", { type: "password", class: "input focus-ring" });
  const errBox = el("div", { style: "color:var(--danger);font-size:12.5px;margin-bottom:12px;font-family:var(--font-body);" });
  const field = (label, node) => el("label", { class: "field" }, [el("div", { class: "field-label" }, [text(label)]), node]);
  container.appendChild(field("Current password", currentInput));
  container.appendChild(field("New password", nextInput));
  container.appendChild(field("Confirm new password", confirmInput));
  container.appendChild(errBox);
  const saveBtn = el("button", { class: "btn-primary focus-ring" }, [text("Update password")]);
  saveBtn.addEventListener("click", async () => {
    errBox.textContent = "";
    if (nextInput.value.length < 8) { errBox.textContent = "New password should be at least 8 characters."; return; }
    if (nextInput.value !== confirmInput.value) { errBox.textContent = "Passwords don't match."; return; }
    saveBtn.disabled = true;
    try {
      await api("/api/admin/change-password", { method: "POST", body: { current: currentInput.value, next: nextInput.value } });
      pushToast({ title: "Password updated" });
      currentInput.value = ""; nextInput.value = ""; confirmInput.value = "";
    } catch (e) {
      errBox.textContent = e.message;
    } finally {
      saveBtn.disabled = false;
    }
  });
  container.appendChild(saveBtn);

  return container;
}
